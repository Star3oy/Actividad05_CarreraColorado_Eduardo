<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_paginawebempresarial' );

/** Database username */
define( 'DB_USER', 'lalonchera' );

/** Database password */
define( 'DB_PASSWORD', 'xKRRER@0910x' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Eg/<,VL;b0>4#(Y=*j=xU08_nhAxFeMfxvNvdUIl&d09{WPOA=:_. %9Pak8nTtC' );
define( 'SECURE_AUTH_KEY',  'zJW7:u7GuF<i1@VCDmauQ?3]&ON$jCi+2|?;Qw-5H5.1Kur]K<Hw,g:SjX@CWjpV' );
define( 'LOGGED_IN_KEY',    'Yop(- ZRI0(Z_>o4>$ze?/)LK$}~-x9fQP^GZ%Ek;U<$+J/My2h.cn>skaEgo(&8' );
define( 'NONCE_KEY',        'v%bTh7gt@=[HXZL(gc^-9;vRzezG];S@|[buf5pyZFfRI+A!Wf`pM[t],o<xSS#j' );
define( 'AUTH_SALT',        '#2r@cTu_YJ61/b+]yE@!#G1V{e3hZ;kr6KZO;$S- ++agY@l+(=ct|pg&pGLl0(x' );
define( 'SECURE_AUTH_SALT', 'z1&4xa[jt`WdIeINjG3Jp~mb+R>QAdpyDhMiGlc/idNN_Ot.V^!?KZThIg?Kn2Sz' );
define( 'LOGGED_IN_SALT',   'f}-2HZ)iqE5|AzYrg_cjjC6+v2(F]oYhkz 4Nz7&;R:1~1(!sK.<^:x}LJ$<~bD5' );
define( 'NONCE_SALT',       'oM~;k<Ey1Uwot$atU@qKMlYR%7L!z9BlkEH[%V{Z7X6hQtE~_~t(*2_$<.>Ui/Ga' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
